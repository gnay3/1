// JavaScript for the Japanese learning dashboard
function initDashboard() {
  // Copy the global `vocab` array into a local variable.  When served as a
  // static site, `vocab` is defined in static/vocab.js.  The script tags in
  // dashboard.html load `vocab.js` before this script, so `vocab` will be
  // available here.  If the site is extended to use an API, this fallback
  // can be replaced with a fetch call similar to the commented code below.
  let vocabData = typeof vocab !== 'undefined' ? Array.from(vocab) : [];

  // All entries in the dataset already include Chinese translations.  If
  // additional translation mappings are needed in the future, define them
  // here and apply them conditionally.
  // Category translations from English to Chinese for display purposes. When adding
  // new categories in vocab.js, update this mapping accordingly. If a category
  // is not found, the original name will be displayed.
  // Category translations not needed because categories are already in Chinese
  const categoryTranslations = {};
  const searchInput = document.getElementById('searchInput');
  const cardsContainer = document.getElementById('cardsContainer');
  const categoryButtons = document.querySelectorAll('.category-btn');
  let selectedCategory = 'All';

  // Uncomment the following block if serving data via API
  /*
  fetch('/api/vocab')
    .then((response) => response.json())
    .then((data) => {
      vocabData = data;
      renderCards();
    })
    .catch((err) => {
      console.error('Failed to load vocabulary:', err);
    });
  */

  // Initial render
  renderCards();

  // Populate overview categories in the hero section
  populateOverview();

  // AI assistant section has been removed; no need to bind related actions

  // Event: search input
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      renderCards();
    });
  }

  // Event: category buttons
  categoryButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      categoryButtons.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      selectedCategory = btn.dataset.category;
      renderCards();
    });
  });

  // Render cards based on search and selected category
  function renderCards() {
    if (!cardsContainer) return;
    const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
    cardsContainer.innerHTML = '';
    vocabData.forEach((item) => {
      const itemCategory = item.category || item.scene || '';
      const matchesCategory = selectedCategory === 'All' || itemCategory === selectedCategory;
      const matchesSearch =
        item.word.toLowerCase().includes(query) ||
        item.reading.toLowerCase().includes(query) ||
        item.translation.toLowerCase().includes(query);
      if (matchesCategory && matchesSearch) {
        const card = document.createElement('div');
        card.className = 'card';
        const displayCategory = item.category || item.scene || '';
        card.innerHTML = `
          <div class="card-title">${item.word}</div>
          <div class="card-subtitle">${item.translation}</div>
          <div class="card-category">${displayCategory}</div>
        `;
        card.addEventListener('click', () => showDetails(item));
        cardsContainer.appendChild(card);
      }
    });
  }

  // Modal elements
  const modal = document.getElementById('detailsModal');
  const closeModalBtn = document.getElementById('closeModal');

  if (closeModalBtn) {
    closeModalBtn.addEventListener('click', hideDetails);
  }

  // Show details of a vocabulary item in the modal
  function showDetails(item) {
    const detailWord = document.getElementById('detailWord');
    const detailReading = document.getElementById('detailReading');
    const detailTranslation = document.getElementById('detailTranslation');
    const detailPart = document.getElementById('detailPart');
    const detailScene = document.getElementById('detailScene');
    const detailMistake = document.getElementById('detailMistake');
    const detailStructure = document.getElementById('detailStructure');
    const collList = document.getElementById('detailCollocations');
    const detailExample = document.getElementById('detailExample');
    if (detailWord) detailWord.textContent = item.word;
    if (detailReading) detailReading.textContent = item.reading;
    if (detailTranslation) detailTranslation.textContent = item.translation;
    if (detailPart) detailPart.textContent = item.part;
    if (detailScene) detailScene.textContent = item.scene || item.category || '';
    // 显示易错点或中式误区，如果不存在则留空
    if (detailMistake) detailMistake.textContent = item.mistake || item.explanation || '';
    // 结构说明字段用于显示语感说明或结构；优先使用结构字段，其次使用语感说明
    if (detailStructure) detailStructure.textContent = item.structure || item.explanation || '';
    if (collList) {
      collList.innerHTML = '';
      (item.collocations || []).forEach((coll) => {
        const li = document.createElement('li');
        li.textContent = coll;
        collList.appendChild(li);
      });
    }
    if (detailExample) detailExample.textContent = item.example;
    if (modal) {
      modal.style.display = 'block';
      modal.setAttribute('aria-hidden', 'false');
    }
    // Play audio button
    const playBtn = document.getElementById('playAudio');
    if (playBtn) {
      playBtn.onclick = () => {
        // Use Japanese voice if available
        const utterance = new SpeechSynthesisUtterance(item.word);
        // Try to select a Japanese voice; fallback to system default
        const voices = window.speechSynthesis.getVoices();
        const jaVoice = voices.find((v) => v.lang && v.lang.toLowerCase().startsWith('ja'));
        if (jaVoice) {
          utterance.voice = jaVoice;
        }
        utterance.lang = 'ja-JP';
        window.speechSynthesis.speak(utterance);
      };
    }
  }

  // Hide modal
  function hideDetails() {
    if (modal) {
      modal.style.display = 'none';
      modal.setAttribute('aria-hidden', 'true');
    }
    window.speechSynthesis.cancel();
  }

  // Hide modal when clicking outside of the content
  window.addEventListener('click', (event) => {
    if (event.target === modal) {
      hideDetails();
    }
  });

  // Expose functions globally if needed
  window.initDashboard = initDashboard;

  /**
   * Populate the overview categories section with all available categories from vocabData.
   * Each category is displayed as a small label in the overview section.
   */
  function populateOverview() {
    const overviewContainer = document.getElementById('overviewList');
    if (!overviewContainer) return;
    const categories = [...new Set(vocabData.map((item) => item.category))].sort();
    overviewContainer.innerHTML = '';
    categories.forEach((cat) => {
      const span = document.createElement('span');
      span.className = 'overview-item';
      span.textContent = cat;
      overviewContainer.appendChild(span);
    });
  }

  /**
   * Bind click handlers for AI assistant cards. The assistant implements simple
   * word search, grammar lookup and rudimentary grammar checking for demo purposes.
   */
  function bindAIActions() {
    const wordCard = document.getElementById('aiWordSearch');
    const grammarCard = document.getElementById('aiGrammarSearch');
    const checkCard = document.getElementById('aiGrammarCheck');
    if (wordCard) {
      wordCard.addEventListener('click', () => {
        const query = prompt('请输入要查询的日语或中文词语：');
        if (!query) return;
        // Search for matching entries by word, reading or translation
        const lower = query.trim().toLowerCase();
        const matches = vocabData.filter((item) => {
          return (
            item.word.toLowerCase() === lower ||
            item.reading.toLowerCase() === lower ||
            item.translation.toLowerCase() === lower
          );
        });
        if (matches.length > 0) {
          const item = matches[0];
          let msg = `${item.word} (${item.reading})\n意思: ${item.translation}\n词性: ${item.part}`;
          if (item.collocations && item.collocations.length > 0) {
            msg += `\n常见搭配:\n- ${item.collocations.join('\n- ')}`;
          }
          if (item.example) {
            msg += `\n例句: ${item.example}`;
          }
          alert(msg);
        } else {
          alert('未找到相应词语。');
        }
      });
    }
    if (grammarCard) {
      grammarCard.addEventListener('click', () => {
        const grammar = prompt('请输入要查询的语法点（例如：「～です」、「～ません」）：');
        if (!grammar) return;
        const rules = getGrammarRules();
        const key = grammar.trim();
        if (rules[key]) {
          alert(`${key}：\n${rules[key]}`);
        } else {
          alert('暂未找到该语法的解释。');
        }
      });
    }
    if (checkCard) {
      checkCard.addEventListener('click', () => {
        const sentence = prompt('请输入需要检查的日语句子：');
        if (!sentence) return;
        // Very simple checker: warn if sentence does not end with 句末标点
        const trimmed = sentence.trim();
        if (!/[。!！?？]$/.test(trimmed)) {
          alert('建议在句末加上句号（。）。');
        } else {
          alert('未发现明显语法问题（仅供参考）。');
        }
      });
    }
  }

  /**
   * Return a simple dictionary of grammar explanations. This is a small subset
   * intended for demonstration. More comprehensive grammar could be added here.
   */
  function getGrammarRules() {
    return {
      '〜です': '用于礼貌陈述。接在名词、形容词或动词连体形后，表示判断或断定，例如：これは本です。',
      '〜ません': '「〜ます」的否定形式，表示不做某动作，例如：食べません（不吃）。',
      '〜ました': '「〜ます」的过去式，表示过去完成或经验，例如：昨日映画を見ました。',
      '〜でしょう': '表示推测或询问对方意见，常译为“吧”“不是吗”，例如：明日は雨でしょう。'
    };
  }
}

// Run dashboard initialisation on DOMContentLoaded if present
document.addEventListener('DOMContentLoaded', function () {
  if (document.getElementById('cardsContainer')) {
    initDashboard();
  }
});

// Global authentication helpers accessible from HTML
window.isLoggedIn = function () {
  return localStorage.getItem('loggedIn') !== null;
};

window.logoutUser = function () {
  localStorage.removeItem('loggedIn');
  window.location.href = 'index.html';
};